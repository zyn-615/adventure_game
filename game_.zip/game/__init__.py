"""
奇幻冒险游戏
模块化版本
"""

__version__ = "3.2.0"
__author__ = "Adventure Game Team"