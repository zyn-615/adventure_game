"""
游戏世界模块
"""

from .shops import WeaponShop, MagicShop, PetShop, shop, discount_shop

__all__ = ['WeaponShop', 'MagicShop', 'PetShop', 'shop', 'discount_shop']